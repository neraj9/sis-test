package com.sis.common.exception;

public class NotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1989890001L;

}
