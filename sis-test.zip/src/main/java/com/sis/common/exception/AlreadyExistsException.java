package com.sis.common.exception;

public class AlreadyExistsException extends RuntimeException {

	private static final long serialVersionUID = 197898978670670L;

}
